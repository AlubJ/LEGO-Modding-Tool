

============================| About |============================

            This program can import meshes and textures
              into a .GHG file within a few clicks.

			     Made By:
			   GUI:  Alub
                           GHG:  Skulluse
                           PLY:  Aaron


==========================| Change Log |=========================
			     v0.0.2.2

- Fixed directory error when any directory with a space wouldn't work.
- UI improvments.