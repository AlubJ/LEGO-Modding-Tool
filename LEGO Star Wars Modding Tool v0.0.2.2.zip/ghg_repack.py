#!/usr/bin/python

import sys
import io

try:
	imput_ghg = sys.argv [2]
	word = sys.argv [1]
#	strcture_file_name = sys.argv [3]
	
except IndexError:
	print ("Error !Not enough arguments given, try 'python ghg_repack. -help'")
	exit ()

if (sys.argv [1] == "-help"):
	print ("This script can swap between meshs and replace images wih the same size image.")
	print ("To do mesh swap:")
	print ("\"python mesh_swap <your ghg.GHG> <Number Of Model> <The Prefix Of The Model>\"")
	print ("*Notice ! Face (not head) Models (the firs two most of The time) can't be replace. You can replace helmets and heads")
	print ("To do image swap:")
	print ("\"python dds_swap <your ghg.GHG> <name of image.dds> <number of image>\"")
	print ("*Notice ! Size of the image SOULD be the SAME as the image that you swaped with.")
	exit ()
		


rest_of_file = []
dds_num = 0
dds_meta = []
dds_file = []
nu20_size = 0
vertex_num = 0
vertex_data = []
index_num = 0
index_data = []
parts_num = 0
parts_data = []
#test_output = open ("test.txt", "wb")
i_c = 0
part_num = 0


def nu20_size_file ():
	global dds_num
	global dds_meta
	global dds_file
	global nu20_size
	global vertex_num
	global vertex_data
	global index_num
	global index_data
	global parts_num
	global parts_data
	global rest_of_file
	global i_c
	
	i_c = 0
	size_of_file = 4 + 2
	while (i_c < dds_num):
		size_of_file += len (dds_meta [i_c])
		size_of_file += len (dds_file [i_c])
		i_c += 1
	size_of_file += 2
	i_c = 0
	while (i_c < vertex_num):
		size_of_file += len(vertex_data [i_c])
		i_c += 1
	size_of_file += 2
	i_c = 0
	while (i_c < index_num):
		size_of_file += len(index_data [i_c])
		i_c += 1
	size_of_file += len (rest_of_file [0])
	
	return (size_of_file)


def ghg_unpack (ghg_file):
	global rest_of_file
	global dds_num
	global dds_meta
	global dds_file
	global nu20_size
	global vertex_num
	global vertex_data
	global index_num
	global index_data
	global parts_num
	global parts_data
	global i_c
	mf_i = 0
	dm_i = 0
	df_i = 0	
	dds_size = 0
	vertex_size = 0
	index_size = 0
	vd_i = 0
	i_c = 0
	nu20_size = int.from_bytes (ghg_file.read (4), "little")#nu20 size
	print ("Size to NU20: " + str (nu20_size))
	dds_num = int.from_bytes (ghg_file.read (2), "little")
	print ("Number of images: " + str (dds_num) + "\n")
	while (i_c < dds_num):
		dds_meta.append (ghg_file.read (24))
		dds_size = int.from_bytes ((dds_meta [dm_i]) [20 : 24], "little")
		dds_file.append (ghg_file.read (dds_size))
		dm_i += 1
		df_i += 1
		i_c += 1

	vertex_num = int.from_bytes (ghg_file.read (2), "little")
	print ("\nNumber of vertex lists : " + str (vertex_num) + "\n")
	i_c = 0
	line_readed = ""
	while (i_c < vertex_num):
		line_readed = (ghg_file.read (4))
		vertex_size = int.from_bytes (line_readed, "little")
		print("Vertex list size: " + str (vertex_size))#debug
		vertex_data.append (line_readed + ghg_file.read (vertex_size))
		vd_i += 1
		i_c += 1
		
	index_num = int.from_bytes (ghg_file.read (2), "little")
	print ("\nNumber of index lists : " + str (index_num) + "\n")
	i_c = 0
	line_readed = ""
	while (i_c < index_num):
		line_readed = (ghg_file.read (4))
		index_size = int.from_bytes (line_readed, "little")
		print("Index list size: " + str (index_size))#debug
		index_data.append (line_readed + ghg_file.read (index_size))
		vd_i += 1
		i_c += 1	
	
	byte_read = ghg_file.read (1)
	content_all = byte_read
	while (1):
		byte_read = ghg_file.read (1)
		if (byte_read != b""):
			content_all += byte_read
		else:
			break
	nu20_loc = content_all.find (b"\x4e\x55\x32\x30") - 4
	rest_of_file.append (content_all [0 : nu20_loc])
	content = content_all [nu20_loc : len (content_all)]
	GSNH_loc = content.find (b"\x47\x53\x4e\x48")
	if (GSNH_loc == -1):
		print ("Error ! can't work on the model !")
		exit ()
	pose = GSNH_loc + 60
	#print ("offset: " + str (len (rest_of_file [0]) + GSNH_loc))
	
	pose += int.from_bytes (content [pose : pose + 4],"little")
	pose += 20
	parts_num = int.from_bytes (content [pose : pose + 4],"little")
	print ("\nNumber of parts: " + str (parts_num) + "\n")
	pose += 4
	pose += 8
	#print (pose)
	parts_pose = pose + int.from_bytes (content [pose : pose + 4],"little", signed=True)
	#print (int.from_bytes (content [pose : pose + 4],"little", signed=True))
	rest_of_file.append (content [0 : parts_pose])
	for i in (range (0, parts_num - 1)):
		parts_data.append (content [parts_pose : parts_pose + 56])
		#print (len (parts_data [i]))
		#test_output.write (parts_data [i])
		print ("Part " + str (i))
		pose += 4
		rest_of_file.append (content [parts_pose + 56 : pose + int.from_bytes (content [pose : pose + 4],"little", signed=True)])
		parts_pose = pose + int.from_bytes (content [pose : pose + 4], "little", signed=True)
	parts_data.append (content [parts_pose : parts_pose + 56])
	print ("Part " + str (parts_num - 1))
	rest_of_file.append (content [parts_pose + 56 : len (content)])		
	
		
def dds_swap (dds_r_data_file_name, dds_r_num):
	global dds_num
	global dds_meta
	global dds_file
	print ("\nSwaping images...\n")
	dds_r_data_file = open (dds_r_data_file_name, "rb")
	print ("Image number: " + dds_r_num)
	dds_size = int.from_bytes ((dds_meta [int (dds_r_num)]) [20 : 24], "little")
	dds_r_data = dds_r_data_file.read (int (dds_size))

	print ("\nImage readed")
	#test_output.write (dds_r_data)
	dds_file [int (dds_r_num)] = dds_r_data
	print ("Image swapped")
	
	
def part_swap (part_num_r, part_name):
	global dds_num
	global dds_meta
	global dds_file
	global nu20_size
	global vertex_num
	global vertex_data
	global index_num
	global index_data
	global parts_num
	global parts_data
	global i_c
	
	i_c = 0
	
	vertex_num += 1
	index_num += 1
	
	print ("\nOpening partData...\n")
	try:
		part_data_file = open (part_name + "_partData.dat", "rb")
	except IOError:
		print (part_name + "_partData.dat is not found")
		exit ()
	part_data = ""
	part_data = part_data_file.read (56)
	position = part_data.find (b"\x78\x78\x78\x78\x78\x78\x78\x78")
	#print (position)
	if (position == -1):
		print ("The xxxxxxxx part dose not found in the file, do not modify the file")
		exit ()
	new_part_data = part_data [0 : position]
	new_part_data += (index_num - 1).to_bytes (4, byteorder = "little")
	new_part_data += (vertex_num - 1).to_bytes (4, byteorder = "little")
	new_part_data += part_data [position + 8 : len (part_data)]
#	test_output.write (new_part_data)
	
	print ("\nSwapping...\n")
	#test_output.write (parts_data [int (part_num_r)])
	#test_output.write (b"\xff\xff")
	parts_data [int (part_num_r)] = new_part_data
	#test_output.write (parts_data [int (part_num_r)])
	print ("\nOpening vertexList...\n")
	try:
		vertex_file = open (part_name + "_vertexList.dat", "rb")
	except IOError:
		print (part_name + "_vertexList.dat is not found")
		exit ()
	line_readed = (vertex_file.read (4))
	vertex_size = int.from_bytes (line_readed, "little")
	vertex_data.append (line_readed + vertex_file.read (vertex_size))
	print ("\nOpening indexList...\n")
	try:
		index_file = open (part_name + "_indexList.dat", "rb")
	except IOError:
		print (part_name + "_indexList.dat is not found")
		exit ()
	line_readed = (index_file.read (4))
	index_size = int.from_bytes (line_readed, "little")
	index_data.append (line_readed + index_file.read (index_size))
	
	nu20_size = nu20_size_file ()
	

def ghg_repack (repack_ghg_name):
	global rest_of_file
	global dds_num
	global dds_meta
	global dds_file
	global nu20_size
	global vertex_num
	global vertex_data
	global index_num
	global index_data
	global parts_num
	global parts_data
	global i_c
	print ("Repack...\n")
	repack_ghg = open (repack_ghg_name, "wb")
	repack_ghg.write (nu20_size.to_bytes (4, byteorder = "little"))
	repack_ghg.write (dds_num.to_bytes (2, byteorder = "little"))
	i_c = 0
	print ("Repacking Images...\n")
	while (i_c < dds_num):
		print ("Repacking image " + str (i_c))
		repack_ghg.write (dds_meta [i_c])
		repack_ghg.write (dds_file [i_c])
		i_c += 1
	repack_ghg.write (vertex_num.to_bytes (2, byteorder = "little"))
	i_c = 0
	print ("\nRepacking vertex lists...\n")
	while (i_c < vertex_num):
		print ("Repacking vertex list " + str (i_c))
		repack_ghg.write (vertex_data [i_c])
		i_c += 1
	repack_ghg.write (index_num.to_bytes (2, byteorder = "little"))
	i_c = 0
	print ("\nRepacking index lists...\n")
	while (i_c < index_num):
		print ("Repacking index list " + str (i_c))
		repack_ghg.write (index_data [i_c])
		i_c += 1
	repack_ghg.write (rest_of_file [0])
	repack_ghg.write (rest_of_file [1])
	i_c = 0
	print ("\nRepacking parts...\n")
	while (i_c < parts_num):
		print ("Repacking part " + str (i_c))
		repack_ghg.write (parts_data [i_c])
		repack_ghg.write (rest_of_file [2 + i_c])
		i_c += 1
#	repack_ghg.write (rest_of_file [2])
	repack_ghg.close
	
#def txt_file_load (txt_file):
#	fixed_txt = []
#	line_reading = ""
#	while ()

if (((imput_ghg.find (".GHG", len(imput_ghg) - 4, len(imput_ghg))) == -1) and ((imput_ghg.find (".ghg", len(imput_ghg) - 4, len(imput_ghg))) == -1)):
	print ("Error ! File must be in a GHG format")
	exit ()
try:
	ghg_model = open(imput_ghg, "rb")
except IOError:
	print ("Error ! GHG file dose not exist")
	exit ()
#
#try:
#	strcture_file = io.open(strcture_file_name, "r", encoding='utf-8', errors='ignore')
#except IOError:
#	print ("Error ! Structure file dose not exist")
#	exit ()
	

#print (strcture_file.read())
ghg_unpack (ghg_model)

dds_position = 0
dds_data_given = ""
part_r_num = 0
part_name = ""

if (sys.argv [1] == "dds_swap"):
	try:
		dds_data_given = sys.argv [3]
	except IndexError :
		print ("Image data must be given")
		exit ()
	try:
		dds_position = sys.argv [4]
	except IndexError :
		print ("Image index must be given")
		exit ()
	except TypeError :
		print ("Image index must be an intiger")
		exit ()
		
	dds_swap (dds_data_given, dds_position)

else :

	if (sys.argv [1] == "parts_swap"):
		try:
			part_r_num = sys.argv [3]
		except IndexError :
			print ("Part number must be given")
			exit ()
		try:
			part_name = sys.argv [4]
		except IndexError :
			print ("Model name must be given")
			exit ()
		except TypeError :
			print ("Image index must be an intiger")
			exit ()
			
		part_swap (part_r_num, part_name)
	else:
		print ("For help type \"python ghg_repack.py -help\"")

ghg_repack (imput_ghg [0 : len (imput_ghg) - 4] + "_REPACK" + imput_ghg [len (imput_ghg) - 4 : len (imput_ghg)])

print ("\n\nFinnished") #debug
ghg_model.close()
#test_output.close()